package edu.psu.ist.gymappfinalproject;

import static android.content.ContentValues.TAG;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.snackbar.Snackbar;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private static final String TAG = "MainActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        //Log out Button
        Button button = findViewById(R.id.log_out_button);
        button.setOnClickListener(this);

        //Profile Button
        Button myProfileButton = findViewById(R.id.profile_button);
        myProfileButton.setOnClickListener(this);

        //Calendar Button
        Button calendarButton = findViewById(R.id.calendar_button);
        calendarButton.setOnClickListener(this);

        //My exercises button
        Button myExercises = findViewById(R.id.exercise_button);
        myExercises.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        if (view.getId() == R.id.log_out_button) {
            Log.d(TAG, "Log out button clicked!");
            Intent loginIntent = new Intent(this, LoginActivity.class);
            startActivity(loginIntent);
            Snackbar.make(view, "Logged out!", Snackbar.LENGTH_SHORT).show();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int menuId = item.getItemId();

        if (menuId == R.id.menu_info) {
            AlertDialog.Builder d = new AlertDialog.Builder(this);
            d.setTitle(R.string.about_info_title);
            d.setMessage(R.string.about_gym_guru);
            d.setPositiveButton("OK", null);
            d.show();
            Log.d(TAG, "Info menu clicked!");
            return true;
        } else if (menuId == R.id.menu_register) {
            Log.d(TAG, "Register menu clicked!");
            Intent registerIntent = new Intent(this, RegisterActivity.class);
            startActivity(registerIntent);
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
