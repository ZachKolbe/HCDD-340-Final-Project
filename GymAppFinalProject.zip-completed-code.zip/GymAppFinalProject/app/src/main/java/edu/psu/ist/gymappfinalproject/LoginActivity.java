package edu.psu.ist.gymappfinalproject;

import static android.content.ContentValues.TAG;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.material.snackbar.Snackbar;

public class LoginActivity extends AppCompatActivity implements View.OnClickListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        Button button = findViewById(R.id.login_button);
        button.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        EditText inputEmail = findViewById(R.id.input_email);
        String email = inputEmail.getText().toString();

        EditText inputPassword = findViewById(R.id.input_password);
        String password = inputPassword.getText().toString();
        Log.d(TAG, "Email entered: " + email + " and Password: " + password);

        if(view.getId() == R.id.login_button) {
            Intent newLogin = new Intent(this, MainActivity.class);
            startActivity(newLogin);
        }
    }

}