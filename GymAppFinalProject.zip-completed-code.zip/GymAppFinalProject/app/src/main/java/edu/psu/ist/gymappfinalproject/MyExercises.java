package edu.psu.ist.gymappfinalproject;

import static android.content.ContentValues.TAG;
import static android.webkit.ConsoleMessage.MessageLevel.LOG;

import android.content.Intent;
import android.nfc.Tag;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.tabs.TabLayout;

public class MyExercises extends AppCompatActivity implements View.OnClickListener {

    private static final String TAG = "MyExercises";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_my_exercises);

        ArrayAdapter<CharSequence> adapter =
                ArrayAdapter.createFromResource(this,
                        R.array.new_max_array,
                        android.R.layout.simple_spinner_item);

        adapter.setDropDownViewResource(
                android.R.layout.simple_spinner_dropdown_item);

        Spinner spinner;
        spinner = findViewById(R.id.spinner_personal_bests);
        spinner.setAdapter(adapter);

        //Back button
        Button backButton = findViewById(R.id.back_button);
        backButton.setOnClickListener(this);

    }

    @Override
    public void onClick(View view) {
        if (view.getId() == R.id.back_button) {
            Intent returnToHome = new Intent(this, MainActivity.class);
            startActivity(returnToHome);
        }
    }
}