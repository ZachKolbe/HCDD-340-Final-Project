package edu.psu.ist.gymappfinalproject;

import static android.content.ContentValues.TAG;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.material.snackbar.Snackbar;

public class RegisterActivity extends AppCompatActivity implements View.OnClickListener {

    private SharedPreferences sharedPreferences;
    public static final String SHARED_PREF_NAME  = "GYM_GURU";
    public static final String EMAIL_KEY = "EMAIL";
    public static final String PASSWORD_KEY = "PASSWORD";
    public static final String FIRST_NAME_KEY = "FIRST_NAME";
    public static final String LAST_NAME_KEY = "LAST_NAME";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        Button button = findViewById(R.id.register_button);
        button.setOnClickListener(this);

        sharedPreferences = getSharedPreferences(SHARED_PREF_NAME, MODE_PRIVATE);

    }

    @Override
    public void onClick(View view) {
        EditText inputFirstName = findViewById(R.id.input_first_name);
        String fName = inputFirstName.getText().toString();

        EditText inputLastName = findViewById(R.id.input_last_name);
        String lName = inputLastName.getText().toString();

        EditText inputEmail = findViewById(R.id.input_email);
        String email = inputEmail.getText().toString();

        EditText inputPassword = findViewById(R.id.input_password);
        String password = inputPassword.getText().toString();
        Log.d(TAG, "Email entered: " + email + " and Password: " + password + " First Name: " + fName + " Last Name: " + lName);

        if (view.getId() == R.id.register_button) {
            Button button = findViewById(R.id.register_button);
            Snackbar.make(button, "You are now Registered!", Snackbar.LENGTH_LONG).show();

            //Got code from ChatGPT to add the desired delay
            new Handler().postDelayed(() -> {
                Intent registerIntent = new Intent(this, MainActivity.class);
                startActivity(registerIntent);
            }, 1500);
        }
    }

    void saveUserInformation(String email, String password, String firstName, String lastName) {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(EMAIL_KEY, email);
        editor.putString(PASSWORD_KEY, password);
        editor.putString(FIRST_NAME_KEY, firstName);
        editor.putString(LAST_NAME_KEY, lastName);
        editor.apply();
    }
}